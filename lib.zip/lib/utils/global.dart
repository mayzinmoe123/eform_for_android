library global;

String apiLink = "http://localhost/eform/public/";

