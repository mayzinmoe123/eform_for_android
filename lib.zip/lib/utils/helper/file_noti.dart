String getfileNoti() {
  return 'png, jpg, jpeg file များသာတင်နိုင်ပါသည်။ \n File Size 2MB ထက်ကျော်သောပုံများတင်မရပါ။';
}
